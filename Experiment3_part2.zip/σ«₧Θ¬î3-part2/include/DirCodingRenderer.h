#pragma once

#include "Renderer.h"



class DirCodingRenderer : public Renderer
{
public:

				DirCodingRenderer() { }
				
void			draw(Grid&);
};

						

